export const firebaseConfig = {
  "projectId": "studio-37422489-bf53f",
  "appId": "1:224236283431:web:c9f01e275b345bc830d002",
  "apiKey": "AIzaSyAZWGMPBfK9mtsB7Gg0WnVucfOMfThQgkA",
  "authDomain": "studio-37422489-bf53f.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "224236283431",
  "storageBucket": "studio-37422489-bf53f.appspot.com"
};
